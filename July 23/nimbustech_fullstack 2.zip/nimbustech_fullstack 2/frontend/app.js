/**
 * NimbusTech Ticket Dashboard — frontend logic.
 *
 * Contains ZERO business logic (no SLA math, no priority scoring) — it only
 * calls the API and renders whatever comes back (NFR11 / FR-F requirements).
 */

const BASE_URL = "http://127.0.0.1:8000";

const els = {
  summary: document.getElementById("summary"),
  errorBanner: document.getElementById("errorBanner"),
  breachedOnly: document.getElementById("breachedOnly"),
  ticketsBody: document.getElementById("ticketsBody"),
  newTicketBtn: document.getElementById("newTicketBtn"),
  newTicketForm: document.getElementById("newTicketForm"),
  cancelNewTicket: document.getElementById("cancelNewTicket"),
};

function showError(message) {
  els.errorBanner.textContent = message;
  els.errorBanner.hidden = false;
}

function clearError() {
  els.errorBanner.hidden = true;
  els.errorBanner.textContent = "";
}

async function apiRequest(path, options = {}) {
  try {
    const res = await fetch(BASE_URL + path, options);
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.detail || `Request failed with status ${res.status}`);
    }
    clearError();
    return await res.json();
  } catch (err) {
    showError(`Could not reach the API (${BASE_URL}). Is it running? Details: ${err.message}`);
    throw err;
  }
}

async function loadSummary() {
  try {
    const summary = await apiRequest("/tickets/summary");
    els.summary.innerHTML =
      `Total: <b>${summary.total_tickets}</b> &nbsp;|&nbsp; Breached: <b>${summary.breached_count}</b>`;
  } catch {
    els.summary.textContent = "Summary unavailable";
  }
}

function renderTickets(tickets) {
  if (tickets.length === 0) {
    els.ticketsBody.innerHTML = `<tr><td colspan="7" class="empty-state">No tickets found.</td></tr>`;
    return;
  }

  els.ticketsBody.innerHTML = tickets
    .map(
      (t) => `
    <tr class="${t.sla_breached ? "breached" : ""}" data-id="${t.ticket_id}">
      <td>${t.ticket_id}</td>
      <td>${t.customer_name}</td>
      <td>${t.category}</td>
      <td>${t.priority_raw}</td>
      <td>
        <select class="status-select" data-id="${t.ticket_id}">
          ${["open", "in_progress", "closed"]
            .map((s) => `<option value="${s}" ${s === t.status ? "selected" : ""}>${s}</option>`)
            .join("")}
        </select>
      </td>
      <td>${t.sla_breached ? '<span class="badge breached">BREACHED</span>' : "on time"}</td>
      <td><button class="danger delete-btn" data-id="${t.ticket_id}">Delete</button></td>
    </tr>`
    )
    .join("");

  els.ticketsBody.querySelectorAll(".status-select").forEach((select) => {
    select.addEventListener("change", () => onStatusChange(select.dataset.id, select.value));
  });
  els.ticketsBody.querySelectorAll(".delete-btn").forEach((btn) => {
    btn.addEventListener("click", () => onDelete(btn.dataset.id));
  });
}

async function loadTickets() {
  els.ticketsBody.innerHTML = `<tr><td colspan="7" class="empty-state">Loading tickets…</td></tr>`;
  const path = els.breachedOnly.checked ? "/tickets/breached" : "/tickets";
  try {
    const tickets = await apiRequest(path);
    renderTickets(tickets);
  } catch {
    els.ticketsBody.innerHTML = `<tr><td colspan="7" class="empty-state">Failed to load tickets.</td></tr>`;
  }
}

async function onStatusChange(ticketId, newStatus) {
  await apiRequest(`/tickets/${ticketId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status: newStatus }),
  }).catch(() => {});
  await refreshAll();
}

async function onDelete(ticketId) {
  await apiRequest(`/tickets/${ticketId}`, { method: "DELETE" }).catch(() => {});
  await refreshAll();
}

async function onCreateTicket(event) {
  event.preventDefault();
  const payload = {
    customer_name: document.getElementById("f_customer").value.trim(),
    category: document.getElementById("f_category").value,
    priority_raw: document.getElementById("f_priority").value,
    sla_hours: Number(document.getElementById("f_sla").value),
    status: "open",
  };

  await apiRequest("/tickets", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  }).catch(() => {});

  els.newTicketForm.reset();
  els.newTicketForm.hidden = true;
  await refreshAll();
}

async function refreshAll() {
  await Promise.all([loadTickets(), loadSummary()]);
}

// ---- wire up events ----
els.breachedOnly.addEventListener("change", loadTickets);
els.newTicketBtn.addEventListener("click", () => {
  els.newTicketForm.hidden = !els.newTicketForm.hidden;
});
els.cancelNewTicket.addEventListener("click", () => {
  els.newTicketForm.hidden = true;
});
els.newTicketForm.addEventListener("submit", onCreateTicket);

// ---- initial load ----
refreshAll();
