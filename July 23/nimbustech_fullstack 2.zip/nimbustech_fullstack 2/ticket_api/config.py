"""Constants for the ticket API. Kept separate from ticket_processor/config.py
on purpose — the script and the API are two independent services that only
ever talk to each other through the report file, never through shared code."""

REPORT_PATH = "data/tickets_report.json"

PRIORITY_SCORES = {"low": 1, "medium": 2, "high": 3, "critical": 4}
VALID_PRIORITIES = set(PRIORITY_SCORES.keys())
CLOSED_STATUS = "closed"
TICKET_ID_PREFIX = "T-"
