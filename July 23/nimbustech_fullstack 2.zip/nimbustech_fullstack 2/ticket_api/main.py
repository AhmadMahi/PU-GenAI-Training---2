"""
FastAPI backend for the NimbusTech ticket dashboard (FR-B11 to FR-B19).

Run with:
    uvicorn ticket_api.main:app --reload --port 8000
"""

import logging

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware

from ticket_api import store
from ticket_api.models import TicketCreate, TicketPatch, TicketReplace

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

app = FastAPI(title="NimbusTech Ticket Triage API", version="2.0.0")

# The frontend is a separate static file/origin — CORS makes that allowed (FR-B19, NFR9).
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup() -> None:
    """Load the processed report into memory when the server starts (FR-B10)."""
    store.load_report()


@app.get("/")
def read_root():
    """Basic health/status endpoint (FR-B11)."""
    return {"status": "ok", "service": "nimbustech-ticket-api"}


@app.get("/tickets")
def list_tickets():
    """Return every ticket currently in memory (FR-B12)."""
    return store.all_tickets()


@app.get("/tickets/breached")
def list_breached_tickets():
    """Return only SLA-breached tickets (FR-B13)."""
    return store.breached_tickets()


@app.get("/tickets/summary")
def get_summary():
    """Return live summary counts for the dashboard (FR-B14)."""
    return store.compute_summary()


@app.get("/tickets/{ticket_id}")
def get_ticket(ticket_id: str):
    """Return one ticket by id, or 404 (FR-B15)."""
    ticket = store.find_ticket(ticket_id)
    if ticket is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ticket not found")
    return ticket


@app.post("/tickets", status_code=status.HTTP_201_CREATED)
def create_ticket(payload: TicketCreate):
    """Create a new ticket (FR-B16)."""
    return store.add_ticket(payload.model_dump())


@app.put("/tickets/{ticket_id}")
def replace_ticket(ticket_id: str, payload: TicketReplace):
    """Full update of status + priority_raw (FR-B17)."""
    ticket = store.find_ticket(ticket_id)
    if ticket is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ticket not found")
    return store.update_ticket(ticket, payload.status, payload.priority_raw)


@app.patch("/tickets/{ticket_id}")
def patch_ticket(ticket_id: str, payload: TicketPatch):
    """Partial update — only the field(s) provided are changed (FR-B17)."""
    ticket = store.find_ticket(ticket_id)
    if ticket is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ticket not found")
    return store.update_ticket(ticket, payload.status, payload.priority_raw)


@app.delete("/tickets/{ticket_id}")
def delete_ticket(ticket_id: str):
    """Delete a ticket by id (FR-B18)."""
    ticket = store.find_ticket(ticket_id)
    if ticket is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ticket not found")
    store.delete_ticket(ticket)
    return {"deleted": ticket_id}
