"""In-memory ticket store, loaded from the report file at startup (FR-B10)."""

import json
import logging
from datetime import datetime

from ticket_api.config import CLOSED_STATUS, PRIORITY_SCORES, REPORT_PATH, TICKET_ID_PREFIX

logger = logging.getLogger(__name__)

# The one and only in-memory "database" for this MVP.
_tickets: list[dict] = []


def load_report(path: str = REPORT_PATH) -> None:
    """Load tickets from the processed report JSON into memory."""
    global _tickets
    try:
        with open(path, encoding="utf-8") as f:
            report = json.load(f)
        _tickets = report.get("tickets", [])
        logger.info("Loaded %d tickets from %s", len(_tickets), path)
    except FileNotFoundError:
        logger.warning("Report file not found at %s — starting with an empty ticket list", path)
        _tickets = []


def all_tickets() -> list[dict]:
    """Return every ticket currently in memory."""
    return _tickets


def breached_tickets() -> list[dict]:
    """Return only tickets currently flagged as SLA-breached."""
    return [t for t in _tickets if t["sla_breached"]]


def find_ticket(ticket_id: str) -> dict | None:
    """Return the ticket dict with this id, or None if not found."""
    for t in _tickets:
        if t["ticket_id"] == ticket_id:
            return t
    return None


def compute_summary() -> dict:
    """Recompute the summary block live from whatever is currently in memory."""
    by_category: dict[str, int] = {}
    breached_count = 0
    for t in _tickets:
        by_category[t["category"]] = by_category.get(t["category"], 0) + 1
        if t["sla_breached"]:
            breached_count += 1
    return {
        "total_tickets": len(_tickets),
        "breached_count": breached_count,
        "by_category": by_category,
    }


def recompute_breach(ticket: dict) -> None:
    """Recalculate sla_breached in place after a create/update (mirrors the script's rule)."""
    if ticket["status"].strip().lower() == CLOSED_STATUS:
        ticket["sla_breached"] = False
        return
    created_at = datetime.fromisoformat(ticket["created_at"])
    deadline = created_at.timestamp() + ticket["sla_hours"] * 3600
    ticket["sla_breached"] = deadline < datetime.now().timestamp()


def next_ticket_id() -> str:
    """Generate the next sequential ticket id, e.g. T-1009."""
    numeric_ids = []
    for t in _tickets:
        suffix = t["ticket_id"].replace(TICKET_ID_PREFIX, "")
        if suffix.isdigit():
            numeric_ids.append(int(suffix))
    next_number = (max(numeric_ids) + 1) if numeric_ids else 1
    return f"{TICKET_ID_PREFIX}{next_number}"


def add_ticket(data: dict) -> dict:
    """Create and store a new ticket dict from validated request data."""
    priority_raw = data["priority_raw"].strip().lower()
    ticket = {
        "ticket_id": next_ticket_id(),
        "customer_name": data["customer_name"].strip(),
        "category": data["category"].strip().lower(),
        "priority_raw": priority_raw,
        "priority_score": PRIORITY_SCORES[priority_raw],
        "created_at": datetime.now().isoformat(),
        "sla_hours": data["sla_hours"],
        "status": data["status"].strip().lower(),
        "sla_breached": False,
    }
    recompute_breach(ticket)
    _tickets.append(ticket)
    logger.info("Created ticket %s", ticket["ticket_id"])
    return ticket


def update_ticket(ticket: dict, status: str | None, priority_raw: str | None) -> dict:
    """Apply an update to an existing ticket dict in place and return it."""
    if status is not None:
        ticket["status"] = status.strip().lower()
    if priority_raw is not None:
        priority_raw = priority_raw.strip().lower()
        ticket["priority_raw"] = priority_raw
        ticket["priority_score"] = PRIORITY_SCORES[priority_raw]
    recompute_breach(ticket)
    logger.info("Updated ticket %s", ticket["ticket_id"])
    return ticket


def delete_ticket(ticket: dict) -> None:
    """Remove a ticket dict from the in-memory store."""
    _tickets.remove(ticket)
    logger.info("Deleted ticket %s", ticket["ticket_id"])
