"""Pydantic request models (FR-B16 / FR-B17)."""

from pydantic import BaseModel, Field

from ticket_api.config import CLOSED_STATUS, VALID_PRIORITIES


class TicketCreate(BaseModel):
    """Body for POST /tickets — every field required for a brand-new ticket."""

    customer_name: str
    category: str
    priority_raw: str = Field(pattern="^(low|medium|high|critical)$")
    sla_hours: float = Field(gt=0)
    status: str = "open"


class TicketReplace(BaseModel):
    """Body for PUT /tickets/{id} — full replace of the editable fields."""

    status: str
    priority_raw: str = Field(pattern="^(low|medium|high|critical)$")


class TicketPatch(BaseModel):
    """Body for PATCH /tickets/{id} — only send the field(s) you want changed."""

    status: str | None = None
    priority_raw: str | None = None
