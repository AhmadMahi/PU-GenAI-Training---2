"""Constants for the ticket-processing script. Nothing hardcoded elsewhere."""

# Row is considered invalid if any required-field check fails (see validators.py)
VALID_PRIORITIES = {"low", "medium", "high", "critical"}

# Maps a priority label to a numeric score used for sorting/display
PRIORITY_SCORES = {"low": 1, "medium": 2, "high": 3, "critical": 4}

# A ticket with this status is never considered SLA-breached, no matter how old
CLOSED_STATUS = "closed"

# If more than this fraction of rows are invalid, abort the whole run
MAX_INVALID_ROW_RATIO = 0.10

# Exit codes
EXIT_OK = 0
EXIT_ABORTED = 1
