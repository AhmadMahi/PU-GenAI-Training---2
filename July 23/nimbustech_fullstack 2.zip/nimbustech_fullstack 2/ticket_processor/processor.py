"""Core classification + report-building logic (FR-B4 to FR-B8)."""

import csv
import logging
from datetime import datetime

from ticket_processor.config import CLOSED_STATUS, PRIORITY_SCORES
from ticket_processor.models import Ticket
from ticket_processor.validators import parse_datetime, validate_row

logger = logging.getLogger(__name__)


def read_csv_rows(path: str) -> list[dict]:
    """Read all rows from the raw tickets CSV as plain dicts."""
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def is_sla_breached(created_at: datetime, sla_hours: float, status: str, now: datetime) -> bool:
    """
    Determine whether a ticket has breached its SLA.

    A ticket is breached if it is not closed AND the deadline
    (created_at + sla_hours) has already passed relative to `now`.
    """
    if status.strip().lower() == CLOSED_STATUS:
        return False
    deadline = created_at.timestamp() + sla_hours * 3600
    return deadline < now.timestamp()


def build_ticket(row: dict, now: datetime) -> Ticket:
    """Convert one validated raw row into a Ticket. Assumes row already passed validate_row()."""
    priority_raw = row["priority_raw"].strip().lower()
    created_at = parse_datetime(row["created_at"].strip())
    sla_hours = float(row["sla_hours"])
    status = row["status"].strip().lower()

    return Ticket(
        ticket_id=row["ticket_id"].strip(),
        customer_name=row["customer_name"].strip(),
        category=row["category"].strip().lower(),
        priority_raw=priority_raw,
        priority_score=PRIORITY_SCORES[priority_raw],
        created_at=created_at,
        sla_hours=sla_hours,
        status=status,
        sla_breached=is_sla_breached(created_at, sla_hours, status, now),
    )


def process_rows(rows: list[dict], now: datetime | None = None) -> tuple[list[Ticket], list[dict]]:
    """
    Validate and classify every row.

    Returns:
        (valid_tickets, invalid_rows) where invalid_rows is a list of
        {"raw_row": ..., "reason": ...} dicts.
    """
    now = now or datetime.now()
    valid_tickets: list[Ticket] = []
    invalid_rows: list[dict] = []

    for row in rows:
        reason = validate_row(row)
        if reason:
            invalid_rows.append({"raw_row": row, "reason": reason})
            logger.warning("Skipping invalid row %s: %s", row.get("ticket_id", "?"), reason)
            continue
        valid_tickets.append(build_ticket(row, now))

    return valid_tickets, invalid_rows


def build_summary(valid_tickets: list[Ticket], total_rows: int, invalid_count: int) -> dict:
    """Compute the summary block (FR-B6)."""
    by_category: dict[str, int] = {}
    breached_count = 0

    for ticket in valid_tickets:
        by_category[ticket.category] = by_category.get(ticket.category, 0) + 1
        if ticket.sla_breached:
            breached_count += 1

    return {
        "total_rows": total_rows,
        "valid_tickets": len(valid_tickets),
        "invalid_rows": invalid_count,
        "breached_count": breached_count,
        "by_category": by_category,
    }


def build_report(valid_tickets: list[Ticket], invalid_rows: list[dict], total_rows: int) -> dict:
    """Assemble the full JSON report (FR-B8 / Appendix B shape)."""
    summary = build_summary(valid_tickets, total_rows, len(invalid_rows))
    return {
        "generated_at": datetime.now().isoformat(),
        "summary": summary,
        "tickets": [t.to_dict() for t in valid_tickets],
        "invalid_rows": invalid_rows,
    }
