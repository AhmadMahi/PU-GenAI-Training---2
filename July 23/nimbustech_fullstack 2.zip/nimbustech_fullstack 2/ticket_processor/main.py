"""
CLI entry point for the ticket-processing script (FR-B9).

Usage:
    python -m ticket_processor.main --input data/tickets_raw.csv --output data/tickets_report.json
"""

import argparse
import json
import logging
import sys

from ticket_processor.config import EXIT_ABORTED, EXIT_OK, MAX_INVALID_ROW_RATIO
from ticket_processor.processor import build_report, process_rows, read_csv_rows

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description="Process NimbusTech raw ticket exports.")
    parser.add_argument("--input", required=True, help="Path to the raw tickets CSV")
    parser.add_argument("--output", required=True, help="Path to write the JSON report")
    return parser.parse_args()


def run(input_path: str, output_path: str) -> int:
    """
    Run the full pipeline: read, validate, classify, and write a report.

    Returns:
        int: process exit code (0 = success, 1 = aborted due to bad data)
    """
    logger.info("Reading raw tickets from %s", input_path)
    try:
        rows = read_csv_rows(input_path)
    except FileNotFoundError:
        logger.error("Input file not found: %s", input_path)
        return EXIT_ABORTED
    except OSError as exc:
        logger.error("Could not read input file: %s", exc)
        return EXIT_ABORTED

    total_rows = len(rows)
    if total_rows == 0:
        logger.error("Input file has no rows: %s", input_path)
        return EXIT_ABORTED

    logger.info("Read %d rows", total_rows)
    valid_tickets, invalid_rows = process_rows(rows)

    invalid_ratio = len(invalid_rows) / total_rows
    logger.info(
        "Valid: %d, Invalid: %d (%.1f%%)",
        len(valid_tickets),
        len(invalid_rows),
        invalid_ratio * 100,
    )

    if invalid_ratio > MAX_INVALID_ROW_RATIO:
        logger.error(
            "Aborting: invalid-row ratio %.1f%% exceeds the %.0f%% threshold. "
            "No report was written — check the upstream export.",
            invalid_ratio * 100,
            MAX_INVALID_ROW_RATIO * 100,
        )
        return EXIT_ABORTED

    report = build_report(valid_tickets, invalid_rows, total_rows)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    logger.info("Report written to %s", output_path)
    return EXIT_OK


def main() -> None:
    """CLI entry point."""
    args = parse_args()
    exit_code = run(args.input, args.output)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
