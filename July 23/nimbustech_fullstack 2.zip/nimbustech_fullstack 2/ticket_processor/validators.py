"""Row-level validation for raw ticket CSV rows (FR-B2 / FR-B3)."""

from datetime import datetime

from ticket_processor.config import VALID_PRIORITIES


def validate_row(row: dict) -> str | None:
    """
    Check a single raw CSV row for problems.

    Args:
        row (dict): a raw row as produced by csv.DictReader

    Returns:
        str | None: a human-readable reason the row is invalid, or None if
        the row is valid.
    """
    ticket_id = (row.get("ticket_id") or "").strip()
    if not ticket_id:
        return "missing ticket_id"

    customer_name = (row.get("customer_name") or "").strip()
    if not customer_name:
        return "missing customer_name"

    priority_raw = (row.get("priority_raw") or "").strip().lower()
    if priority_raw not in VALID_PRIORITIES:
        return f"invalid priority_raw '{row.get('priority_raw')}'"

    sla_hours_raw = row.get("sla_hours")
    try:
        sla_hours = float(sla_hours_raw)
    except (TypeError, ValueError):
        return f"sla_hours is not numeric: '{sla_hours_raw}'"
    if sla_hours <= 0:
        return f"sla_hours must be positive, got {sla_hours}"

    created_at_raw = (row.get("created_at") or "").strip()
    if not _parse_datetime(created_at_raw):
        return f"created_at is not a parseable date: '{created_at_raw}'"

    return None


def _parse_datetime(value: str) -> datetime | None:
    """Try a couple of common formats; return None if none match."""
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


def parse_datetime(value: str) -> datetime:
    """Parse a datetime string, raising ValueError if it truly can't parse.

    Only call this on rows that already passed validate_row().
    """
    parsed = _parse_datetime(value)
    if parsed is None:
        raise ValueError(f"Could not parse datetime: {value}")
    return parsed
