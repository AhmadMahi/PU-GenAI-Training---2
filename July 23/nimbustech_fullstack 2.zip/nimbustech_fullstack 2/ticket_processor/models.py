"""Data structures for a single processed ticket."""

from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class Ticket:
    """A validated, classified support ticket."""

    ticket_id: str
    customer_name: str
    category: str
    priority_raw: str
    priority_score: int
    created_at: datetime
    sla_hours: float
    status: str
    sla_breached: bool

    def to_dict(self) -> dict:
        """Return a JSON-serializable dict representation of this ticket."""
        data = asdict(self)
        data["created_at"] = self.created_at.isoformat()
        return data
