
import logging
from datetime import datetime

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# --------------------------------------------------------------------------
# Setup
# --------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="FastAPI Introduction — Live Demo",
    description="A simple demo app covering APIs, HTTP methods, REST, JSON, and status codes.",
    version="1.0.0",
)

# Allow the standalone demo.html page (opened directly, a different "origin"
# from the API) to call this API from the browser. This is the one bit of
# "extra" config needed whenever a frontend and backend run on different
# origins/ports — worth pointing out live, but nothing fancier than that.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# --------------------------------------------------------------------------
# "Database" — just an in-memory list of dicts. No real DB for this demo.
# --------------------------------------------------------------------------
users_db = [
    {"id": 1, "name": "Priya", "role": "admin", "active": True},
    {"id": 2, "name": "Asha", "role": "user", "active": True},
    {"id": 3, "name": "Rahul", "role": "user", "active": False},
]


# --------------------------------------------------------------------------
# Pydantic models — define the SHAPE of data going in/out.
# This is what gives FastAPI its automatic validation (a "hidden" advantage
# most people don't appreciate until they've built APIs without it).
# --------------------------------------------------------------------------
class UserCreate(BaseModel):
    name: str
    role: str
    active: bool = True


class UserUpdate(BaseModel):
    name: str | None = None
    role: str | None = None
    active: bool | None = None


# --------------------------------------------------------------------------
# Helper (SRP — one small function, one job, reused by several routes)
# --------------------------------------------------------------------------
def find_user(user_id: int):
    """Return the user dict with this id, or None if not found."""
    for user in users_db:
        if user["id"] == user_id:
            return user
    return None


# ==========================================================================
# C0 / C3 / C4 — Root endpoint: what a request/response looks like
# ==========================================================================
@app.get("/")
def read_root():
    """
    Basic root endpoint.

    Talking point: this is a Request (GET /) and a Response
    (status 200 + this JSON body) — the smallest possible example
    of client <-> server communication over HTTP.
    """
    return {
        "message": "Welcome to the FastAPI Introduction demo",
        "docs": "/docs",
        "time": datetime.now().isoformat(),
    }


# ==========================================================================
# C8 — GET: read data, no side effects
# ==========================================================================
@app.get("/users")
def list_users(role: str | None = None):
    """
    Return all users.

    Talking point (query params): pass ?role=admin to filter —
    e.g. GET /users?role=admin
    """
    if role:
        logger.info("Filtering users by role=%s", role)
        return [u for u in users_db if u["role"] == role]
    return users_db


# ==========================================================================
# C8 / C7 — GET with a path parameter + 404 handling
# ==========================================================================
@app.get("/users/{user_id}")
def get_user(user_id: int):
    """
    Return a single user by id — mirrors the GET /users/5 example
    from the FastAPI Introduction chapter.

    Talking point: HTTP is stateless (Hidden Insight #2) — this endpoint
    has no memory of any previous request. Every call re-looks-up the
    user from scratch, every single time.
    """
    user = find_user(user_id)
    if user is None:
        # Talking point: this is what a 404 Not Found looks like in practice
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return user


# ==========================================================================
# C8 — POST: create new data
# ==========================================================================
@app.post("/users", status_code=status.HTTP_201_CREATED)
def create_user(user: UserCreate):
    """
    Create a new user.

    Talking point: the request BODY (JSON) is automatically parsed and
    validated against the UserCreate model. Send bad data (e.g. missing
    "name") and FastAPI rejects it with a 422 before this function even runs
    — that's Pydantic validation working behind the scenes.
    """
    new_id = max((u["id"] for u in users_db), default=0) + 1
    new_user = {"id": new_id, **user.model_dump()}
    users_db.append(new_user)
    logger.info("Created user id=%s", new_id)
    return new_user


# ==========================================================================
# C8 — PUT: replace/update an entire resource
# ==========================================================================
@app.put("/users/{user_id}")
def replace_user(user_id: int, user: UserCreate):
    """
    Replace a user entirely.

    Talking point: PUT expects the FULL resource — every field is
    provided and the whole record is overwritten. Compare this to PATCH
    below, which only touches the fields you actually send.
    """
    existing = find_user(user_id)
    if existing is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    existing.update(user.model_dump())
    logger.info("Replaced user id=%s", user_id)
    return existing


# ==========================================================================
# C8 — PATCH: update part of a resource
# ==========================================================================
@app.patch("/users/{user_id}")
def update_user_partial(user_id: int, user: UserUpdate):
    """
    Partially update a user — only the fields provided are changed.

    Talking point: this is the real difference between PUT and PATCH.
    PATCH with just {"active": false} leaves name/role untouched.
    """
    existing = find_user(user_id)
    if existing is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    updates = user.model_dump(exclude_unset=True)
    existing.update(updates)
    logger.info("Patched user id=%s with fields=%s", user_id, list(updates.keys()))
    return existing


# ==========================================================================
# C8 — DELETE: remove data
# ==========================================================================
@app.delete("/users/{user_id}")
def delete_user(user_id: int):
    """
    Delete a user by id.

    Talking point: after this call succeeds, GET /users/{user_id}
    for the same id will now correctly return a 404.
    """
    existing = find_user(user_id)
    if existing is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    users_db.remove(existing)
    logger.info("Deleted user id=%s", user_id)
    return {"deleted": user_id}


# ==========================================================================
# C9 — REST naming: nouns, not verbs
# ==========================================================================
#   Bad  (verb in the URL):   GET /getUser, POST /createUser
#   Good (noun + HTTP verb):  GET /users/5, POST /users   <- what we did above
#
# ==========================================================================
# C10 — JSON: every response above is automatically returned as JSON.
# FastAPI converts the Python dict/model you return into a JSON body —
# you never call json.dumps() yourself.
# ==========================================================================
#
# ==========================================================================
# C11 — Why FastAPI: try these while the app is running
#   * http://127.0.0.1:8000/docs   -> free interactive Swagger UI
#   * http://127.0.0.1:8000/redoc  -> free alternate docs
#   * Try sending a POST with a missing "name" field -> automatic 422 error,
#     with zero validation code written by you.
# ==========================================================================
