

```bash
python -m venv venv
source venv/bin/activate        # venv\Scripts\activate on Windows
pip install -r requirements.txt
uvicorn main:app --reload
```

Then open:
- http://127.0.0.1:8000/docs — interactive Swagger UI (free, auto-generated)
- http://127.0.0.1:8000/redoc — alternate auto-generated docs

