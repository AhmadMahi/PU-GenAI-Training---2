"""
Domain models for the Retail Inventory & Sales Reconciliation CLI (Milestone 2, Q2.2 / Q2.3).
"""

from dataclasses import dataclass

from calculations import compute_revenue


@dataclass
class Product:
    """A single inventory item."""

    sku: str
    name: str
    unit_price: float
    stock_qty: int
    category: str

    def remaining_stock(self, qty_sold: int) -> int:
        """Stock remaining after qty_sold units are sold (can go negative -- that's oversold)."""
        return self.stock_qty - qty_sold


@dataclass
class SaleTransaction:
    """A single sales transaction line."""

    sku: str
    qty_sold: int
    discount_pct: float
    channel: str
    revenue: float = 0.0

    def line_revenue(self, product: Product) -> float:
        """Compute this transaction's revenue against the given product's unit price."""
        return compute_revenue(product.unit_price, self.qty_sold, self.discount_pct)
