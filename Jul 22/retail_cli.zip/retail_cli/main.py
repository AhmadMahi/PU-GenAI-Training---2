"""
CLI entry point for the Retail Inventory & Sales Reconciliation CLI (Milestone 3, Q3.4/Q3.5).

Run:
    python main.py --inventory sample_data/inventory.json --sales sample_data/sales.csv --output report.json
"""

import argparse
import logging
import sys

from config import DEFAULT_REORDER_THRESHOLD, MAX_MALFORMED_RATIO
from io_utils import load_inventory, load_sales, write_report
from reporting import build_report


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser (FR10)."""
    parser = argparse.ArgumentParser(description="Retail Inventory & Sales Reconciliation CLI")
    parser.add_argument("--inventory", required=True, help="Path to inventory.json")
    parser.add_argument("--sales", required=True, help="Path to sales.csv")
    parser.add_argument("--output", default="report.json", help="Path to write the report JSON")
    parser.add_argument(
        "--reorder-threshold",
        type=int,
        default=DEFAULT_REORDER_THRESHOLD,
        help="Remaining-stock level below which a SKU is flagged low-stock",
    )
    return parser


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    logger = logging.getLogger("retail_cli")

    args = build_parser().parse_args()

    logger.info("Loading inventory from %s", args.inventory)
    inventory = load_inventory(args.inventory)
    logger.info("Loaded %d SKUs", len(inventory))

    logger.info("Loading sales from %s", args.sales)
    sales, malformed_count, total_rows = load_sales(args.sales)

    # NFR2: abort instead of writing a partial report if too many rows were malformed.
    if total_rows and (malformed_count / total_rows) > MAX_MALFORMED_RATIO:
        logger.critical(
            "%d/%d sales rows (%.1f%%) were malformed -- exceeds the %.0f%% threshold. Aborting without writing a report.",
            malformed_count, total_rows, 100 * malformed_count / total_rows, 100 * MAX_MALFORMED_RATIO,
        )
        sys.exit(1)

    report = build_report(inventory, sales, args.reorder_threshold)
    write_report(report, args.output)
    logger.info("Report written to %s", args.output)

    print("\n=== Retail Inventory & Sales Reconciliation -- Daily Summary ===")
    print(f"SKUs in inventory     : {len(inventory)}")
    print(f"Sales rows processed  : {len(sales)} (skipped {malformed_count} malformed of {total_rows})")
    print(f"Unknown SKUs sold     : {len(report['unknown_skus'])}")
    print(f"Oversold SKUs         : {report['oversold_skus']}")
    print(f"Low-stock SKUs        : {report['low_stock_skus']}")
    print(f"Total revenue         : {report['total_revenue']}")


if __name__ == "__main__":
    main()
