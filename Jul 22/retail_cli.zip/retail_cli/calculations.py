"""
Revenue calculation for the Retail Inventory & Sales Reconciliation CLI (FR4 / Milestone 1 Q1.3,
Milestone 2 Q2.5).
"""


def compute_revenue(unit_price: float, qty_sold: int, discount_pct: float) -> float:
    """Compute line revenue, clamping discount_pct to [0, 100] (Q1.3).

    Args:
        unit_price: price per unit.
        qty_sold: units sold.
        discount_pct: discount percentage. Values outside 0-100 are treated as 0 rather than
            silently producing a negative or inflated revenue.
    Returns:
        Revenue rounded to 2 decimal places.
    """
    if discount_pct < 0 or discount_pct > 100:
        discount_pct = 0.0
    revenue = qty_sold * unit_price * (1 - discount_pct / 100)
    return round(revenue, 2)


def category_code_from_sku(sku: str) -> str:
    """Extract the category code from a SKU string, e.g. 'SKU-1001' -> '1' (Q2.5).

    Purely a string operation on the SKU itself -- useful as a sanity cross-check against the
    inventory's declared `category` field, independent of any inventory lookup.

    Raises:
        ValueError: if the SKU doesn't match the expected 'SKU-<digits>' shape.
    """
    try:
        code_part = sku.split("-")[1]
    except (IndexError, AttributeError) as exc:
        raise ValueError(f"Malformed SKU: {sku!r}") from exc
    if not code_part or not code_part[0].isdigit():
        raise ValueError(f"Malformed SKU: {sku!r}")
    return code_part[0]
