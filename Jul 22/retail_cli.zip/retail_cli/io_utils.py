"""
File I/O for the Retail Inventory & Sales Reconciliation CLI -- Milestone 3 (Q3.1, Q3.2, Q3.3).
"""

import csv
import json
import logging

from models import Product, SaleTransaction

logger = logging.getLogger(__name__)


def parse_sale_row(row: dict) -> dict:
    """Validate and cast one raw sales row (Q1.2).

    Args:
        row: a dict of string values, as produced by csv.DictReader.
    Returns:
        A cleaned dict with qty_sold cast to int and discount_pct cast to float.
    Raises:
        ValueError: if a required field is missing/empty or a numeric field is invalid.
    """
    try:
        sku = row["sku"].strip()
        qty_sold = int(row["qty_sold"])
        discount_pct = float(row["discount_pct"])
        channel = row["channel"].strip()
    except KeyError as exc:
        raise ValueError(f"Missing required field: {exc}") from exc
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid numeric field in row {row}: {exc}") from exc

    if not sku or not channel:
        raise ValueError("sku and channel must not be empty")

    return {"sku": sku, "qty_sold": qty_sold, "discount_pct": discount_pct, "channel": channel}


def load_inventory(json_path: str) -> dict:
    """Load the product inventory snapshot (FR1 / Q3.1).

    Returns:
        dict keyed by sku, valued by Product instances.
    """
    with open(json_path, "r") as f:
        raw = json.load(f)
    return {p["sku"]: Product(**p) for p in raw}


def load_sales(csv_path: str) -> tuple:
    """Load and validate the sales batch (FR2/FR3 / Q3.2).

    Malformed rows are logged and skipped -- they never crash the batch (NFR1, coding standard #3).

    Returns:
        (sales, malformed_count, total_rows) -- sales is a list of SaleTransaction instances.
    """
    sales = []
    malformed_count = 0
    total_rows = 0

    with open(csv_path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            total_rows += 1
            try:
                clean = parse_sale_row(row)
            except ValueError as exc:
                logger.warning("Skipping malformed sales row %s: %s", row, exc)
                malformed_count += 1
                continue
            sales.append(SaleTransaction(**clean))

    return sales, malformed_count, total_rows


def write_report(report: dict, output_path: str) -> None:
    """Write the report as indented JSON (FR9 / Q3.3)."""
    with open(output_path, "w") as f:
        json.dump(report, f, indent=2)
