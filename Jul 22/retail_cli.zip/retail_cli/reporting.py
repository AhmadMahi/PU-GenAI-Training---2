"""
Report aggregation for the Retail Inventory & Sales Reconciliation CLI (FR5-FR9 / Milestone 2 Q2.1, Q2.4).
"""

from config import DEFAULT_REORDER_THRESHOLD


def build_report(inventory: dict, sales: list, reorder_threshold: int = DEFAULT_REORDER_THRESHOLD) -> dict:
    """Aggregate revenue by category/channel and compute stock-issue flags.

    Args:
        inventory: dict of sku -> Product, already loaded.
        sales: list of SaleTransaction instances, already parsed.
        reorder_threshold: remaining-stock level below which a SKU is flagged low-stock (FR6).
    Returns:
        A JSON-serializable report dict.
    """
    unknown_skus = set()          # Q2.4: skus sold but not present in inventory (FR7)
    qty_sold_by_sku = {}           # Q2.1: dict accumulator
    revenue_by_category = {}        # Q2.1
    revenue_by_channel = {}          # Q2.1
    total_revenue = 0.0

    for sale in sales:
        product = inventory.get(sale.sku)
        if product is None:
            unknown_skus.add(sale.sku)
            continue

        revenue = sale.line_revenue(product)
        sale.revenue = revenue
        total_revenue += revenue

        qty_sold_by_sku[sale.sku] = qty_sold_by_sku.get(sale.sku, 0) + sale.qty_sold
        revenue_by_category[product.category] = round(
            revenue_by_category.get(product.category, 0.0) + revenue, 2
        )
        revenue_by_channel[sale.channel] = round(
            revenue_by_channel.get(sale.channel, 0.0) + revenue, 2
        )

    oversold_skus = set()      # FR5
    low_stock_skus = set()      # FR6 -- tracked with a set, not a list (Q2.6)
    for sku, qty_sold in qty_sold_by_sku.items():
        product = inventory[sku]
        remaining = product.remaining_stock(qty_sold)
        if qty_sold > product.stock_qty:
            oversold_skus.add(sku)
        if remaining < reorder_threshold:
            low_stock_skus.add(sku)

    return {
        "total_revenue": round(total_revenue, 2),
        "revenue_by_category": revenue_by_category,
        "revenue_by_channel": revenue_by_channel,
        "unknown_skus": sorted(unknown_skus),
        "oversold_skus": sorted(oversold_skus),
        "low_stock_skus": sorted(low_stock_skus),
    }
