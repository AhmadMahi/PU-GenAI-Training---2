"""
Central configuration for the Retail Inventory & Sales Reconciliation CLI.

Per the project's coding standards, every constant used elsewhere in this package lives here --
no magic numbers scattered across modules.
"""

DEFAULT_REORDER_THRESHOLD = 10

# NFR2: abort instead of writing a partial report if more than this fraction of sales rows in a
# batch are malformed.
MAX_MALFORMED_RATIO = 0.10
