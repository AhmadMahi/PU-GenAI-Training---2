# Retail Inventory & Sales Reconciliation CLI — Reference Solution

Reference implementation for Project 2 in the Python Core Refresher Capstone Project Workbook.
Matches the PRD, architecture, and coding standards in that workbook exactly — this is the answer
key, not a variant.

## Run it

```bash
cd retail_cli
python main.py --inventory sample_data/inventory.json --sales sample_data/sales.csv --output report.json
cat report.json
```

Optional flags: `--reorder-threshold` (default `10`).

## Files

| File | Milestone | Purpose |
|---|---|---|
| `config.py` | — | `DEFAULT_REORDER_THRESHOLD`, `MAX_MALFORMED_RATIO` — the only constants in the project |
| `calculations.py` | 1/2 (Q1.3, Q2.5) | `compute_revenue()`, `category_code_from_sku()` |
| `models.py` | 2 (Q2.2/Q2.3) | `Product`, `SaleTransaction` classes |
| `io_utils.py` | 1/3 (Q1.2, Q3.1–Q3.3) | `parse_sale_row()`, `load_inventory()`, `load_sales()`, `write_report()` |
| `reporting.py` | 2 (Q2.1/Q2.4) | `build_report()` — category/channel aggregation, oversold & low-stock flags via `set` |
| `main.py` | 3 (Q3.4/Q3.5) | CLI wiring, logging setup, NFR2 exit-code behavior |

## Sample data

`sample_data/sales.csv` deliberately includes:
- an **oversold SKU** (`SKU-1002`: 10 sold against 8 in stock).
- a **low-stock SKU** after the batch (`SKU-1001`: 50 − 5 = 45 remaining, still above the default
  threshold of 10 — swap in a bigger `qty_sold` or lower `--reorder-threshold` to see this flag fire).
- an **unknown SKU** (`SKU-9999`, not in `inventory.json`).
- a **malformed row** (missing `sku`) — logged as a `WARNING` and skipped, not a crash.

With the default sample data, malformed rows are 1 of 5 (20%) — deliberately **above** the 10%
NFR2 threshold, so running the CLI as-is against the full sample file demonstrates the abort path
(exit code 1, no report written), exactly like the telecom project's sample data. Add a few more
valid rows to `sales.csv` to see the successful path and a populated `report.json`.

## Design notes

- `category_code_from_sku()` lives in `calculations.py` as a pure string operation, independent of
  any inventory lookup — intended as a cross-check utility, not part of the main pipeline.
- `SaleTransaction.line_revenue()` delegates to `calculations.compute_revenue()` rather than
  duplicating the discount-clamping logic — one source of truth for the revenue formula.
- No database — this project's PRD explicitly scopes that out (see the workbook's "Out of Scope").
