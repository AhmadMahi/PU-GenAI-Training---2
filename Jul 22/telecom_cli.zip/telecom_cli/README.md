# Telecom CDR & Billing Insights CLI — Reference Solution

Reference implementation for Project 1 in the Python Core Refresher Capstone Project Workbook.
Matches the PRD, architecture, and coding standards in that workbook exactly — this is the answer
key, not a variant.

## Run it

```bash
cd telecom_cli
python main.py --subscribers sample_data/subscribers.json --cdrs sample_data/cdrs.csv --output report.json
cat report.json
```

Optional flags: `--fraud-threshold-sec` (default `3600`).

## Files

| File | Milestone | Purpose |
|---|---|---|
| `config.py` | — | `RATES`, `DEFAULT_FRAUD_THRESHOLD_SEC`, `MAX_MALFORMED_RATIO` — the only constants in the project |
| `rating.py` | 2 (Q2.1) | `compute_cost()` — dict-based rate lookup |
| `fraud.py` | 2 (Q2.3) | `is_suspicious()` — the two fraud heuristics from FR5 |
| `models.py` | 2 (Q2.2/Q2.3) | `Subscriber`, `CDR` classes |
| `io_utils.py` | 1/2/3 (Q1.2, Q2.5, Q3.1–Q3.3) | `parse_cdr_line()`, `parse_legacy_line()`, `load_subscribers()`, `load_cdrs()`, `write_report()` |
| `reporting.py` | 2 (Q2.4) | `build_report()` — aggregation, unknown-subscriber detection via `set` |
| `main.py` | 3 (Q3.4/Q3.5) | CLI wiring, logging setup, NFR2 exit-code behavior |

## Sample data

`sample_data/cdrs.csv` deliberately includes:
- an **unknown subscriber** (`9999999999`, not in `subscribers.json`) — ends up in `unknown_subscribers`.
- a **malformed row** (`notanumber` as duration) — logged as a `WARNING` and skipped, not a crash.
- a **fraud-suspect call** (`9876543210`, international, 4200s > the 3600s default threshold).

With the default sample data, malformed rows are 1 of 7 (~14%) — deliberately **above** the 10%
NFR2 threshold, so running the CLI as-is against the full sample file demonstrates the abort path
(exit code 1, no report written). To see a normal successful run, either add a couple more valid
rows to `cdrs.csv` first, or raise the threshold for a demo via a modified `config.py` — both are
intentional, so you can observe both code paths.

## Design notes

- `fraud.py` holds the actual rule logic as a plain function; `CDR.is_suspicious()` in `models.py`
  is a thin OOP wrapper around it — keeps the business rule unit-testable independent of the class.
- `parse_legacy_line()` in `io_utils.py` satisfies Q2.5 (string manipulation) but isn't wired into
  `main.py`'s primary flow, since the PRD's ingestion format is CSV, not the legacy pipe format —
  it's available for a follow-up exercise ("what if a legacy CDR source needs supporting too?").
- No database — this project's PRD explicitly scopes that out (see the workbook's "Out of Scope").
