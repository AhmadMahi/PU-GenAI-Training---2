"""
Fraud heuristics for the Telecom CDR & Billing Insights CLI (FR5 / Milestone 2 Q2.3).

Kept as plain functions here (not tied to the CDR class) so the rules are unit-testable in
isolation; models.CDR.is_suspicious() is a thin OOP wrapper around is_suspicious() below.
"""


def is_suspicious(call_type: str, duration_sec: int, cost: float, fraud_threshold_sec: int) -> bool:
    """Return True if a call matches either fraud heuristic from the PRD (FR5).

    Args:
        call_type: "domestic" / "roaming" / "international".
        duration_sec: call duration in seconds.
        cost: the call's already-computed cost.
        fraud_threshold_sec: duration above which a long international call is flagged.
    Returns:
        True if the call looks fraudulent, False otherwise.
    """
    # Rule (a): a "zero-rated leak" -- a real call that produced no charge at all.
    if duration_sec > 0 and cost == 0:
        return True

    # Rule (b): an unusually long international call.
    if call_type == "international" and duration_sec > fraud_threshold_sec:
        return True

    return False
