"""
File I/O for the Telecom CDR & Billing Insights CLI -- Milestone 3 (Q3.1, Q3.2, Q3.3),
plus the legacy line parser from Milestone 2 (Q2.5).
"""

import csv
import json
import logging

from models import CDR, Subscriber
from rating import compute_cost

logger = logging.getLogger(__name__)


def parse_cdr_line(row: dict) -> dict:
    """Validate and cast one raw CDR row (Q1.2).

    Args:
        row: a dict of string values, as produced by csv.DictReader.
    Returns:
        A cleaned dict with duration_sec cast to int.
    Raises:
        ValueError: if a required field is missing, empty, or duration_sec isn't a valid integer.
    """
    try:
        msisdn = row["msisdn"].strip()
        call_type = row["call_type"].strip()
        duration_sec = int(row["duration_sec"])
    except KeyError as exc:
        raise ValueError(f"Missing required field: {exc}") from exc
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid duration_sec value: {row.get('duration_sec')!r}") from exc

    if not msisdn or not call_type:
        raise ValueError("msisdn and call_type must not be empty")

    return {"msisdn": msisdn, "call_type": call_type, "duration_sec": duration_sec}


def parse_legacy_line(line: str) -> dict:
    """Parse a legacy pipe-delimited CDR line, e.g. '9876543210|domestic|180' (Q2.5).

    Normalizes to the same shape parse_cdr_line() produces, so callers don't need to care which
    format a given record originally arrived in.
    """
    parts = [p.strip() for p in line.split("|")]
    if len(parts) != 3:
        raise ValueError(f"Malformed legacy line (expected 3 fields): {line!r}")
    msisdn, call_type, duration_str = parts
    return parse_cdr_line({"msisdn": msisdn, "call_type": call_type, "duration_sec": duration_str})


def load_subscribers(json_path: str) -> dict:
    """Load the subscriber master list (FR1 / Q3.1).

    Returns:
        dict keyed by msisdn, valued by Subscriber instances.
    """
    with open(json_path, "r") as f:
        raw = json.load(f)
    return {s["msisdn"]: Subscriber(msisdn=s["msisdn"], plan_type=s["plan_type"]) for s in raw}


def load_cdrs(csv_path: str, fraud_threshold_sec: int) -> tuple:
    """Load, validate, and rate the CDR batch (FR2/FR3/FR4 / Q3.2).

    Malformed rows are logged and skipped -- they never crash the batch (NFR1, coding standard #3).

    Args:
        csv_path: path to the CDR CSV file.
        fraud_threshold_sec: threshold passed through to CDR.is_suspicious() by callers later.
    Returns:
        (cdrs, malformed_count, total_rows) -- cdrs is a list of CDR instances with cost already computed.
    """
    cdrs = []
    malformed_count = 0
    total_rows = 0

    with open(csv_path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            total_rows += 1
            try:
                clean = parse_cdr_line(row)
            except ValueError as exc:
                logger.warning("Skipping malformed CDR row %s: %s", row, exc)
                malformed_count += 1
                continue

            cost = compute_cost(clean["call_type"], clean["duration_sec"])
            cdrs.append(CDR(
                msisdn=clean["msisdn"],
                call_type=clean["call_type"],
                duration_sec=clean["duration_sec"],
                cost=cost,
            ))

    return cdrs, malformed_count, total_rows


def write_report(report: dict, output_path: str) -> None:
    """Write the report as indented JSON (FR8 / Q3.3)."""
    with open(output_path, "w") as f:
        json.dump(report, f, indent=2)
