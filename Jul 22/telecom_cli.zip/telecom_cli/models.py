"""
Domain models for the Telecom CDR & Billing Insights CLI (Milestone 2, Q2.2 / Q2.3).
"""

from dataclasses import dataclass, field

from fraud import is_suspicious


@dataclass
class CDR:
    """A single validated, already-rated Call Detail Record."""

    msisdn: str
    call_type: str
    duration_sec: int
    cost: float = 0.0

    def is_suspicious(self, fraud_threshold_sec: int) -> bool:
        """Return True if this call matches either fraud heuristic (FR5).

        Args:
            fraud_threshold_sec: duration threshold above which a long international call is flagged.
        """
        return is_suspicious(self.call_type, self.duration_sec, self.cost, fraud_threshold_sec)


@dataclass
class Subscriber:
    """A subscriber and the CDRs billed against them."""

    msisdn: str
    plan_type: str
    calls: list = field(default_factory=list)

    def total_cost(self) -> float:
        """Sum the cost of every call currently attached to this subscriber."""
        return round(sum(c.cost for c in self.calls), 2)
