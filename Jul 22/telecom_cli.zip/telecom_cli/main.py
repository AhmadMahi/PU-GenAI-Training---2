"""
CLI entry point for the Telecom CDR & Billing Insights CLI (Milestone 3, Q3.4/Q3.5).

Run:
    python main.py --subscribers sample_data/subscribers.json --cdrs sample_data/cdrs.csv --output report.json
"""

import argparse
import logging
import sys

from config import DEFAULT_FRAUD_THRESHOLD_SEC, MAX_MALFORMED_RATIO
from io_utils import load_cdrs, load_subscribers, write_report
from reporting import build_report


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser (FR9)."""
    parser = argparse.ArgumentParser(description="Telecom CDR & Billing Insights CLI")
    parser.add_argument("--subscribers", required=True, help="Path to subscribers.json")
    parser.add_argument("--cdrs", required=True, help="Path to cdrs.csv")
    parser.add_argument("--output", default="report.json", help="Path to write the report JSON")
    parser.add_argument(
        "--fraud-threshold-sec",
        type=int,
        default=DEFAULT_FRAUD_THRESHOLD_SEC,
        help="Duration (seconds) above which a long international call is flagged as fraud-suspect",
    )
    return parser


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    logger = logging.getLogger("telecom_cli")

    args = build_parser().parse_args()

    logger.info("Loading subscribers from %s", args.subscribers)
    subscribers = load_subscribers(args.subscribers)
    logger.info("Loaded %d subscribers", len(subscribers))

    logger.info("Loading CDRs from %s", args.cdrs)
    cdrs, malformed_count, total_rows = load_cdrs(args.cdrs, args.fraud_threshold_sec)

    # NFR2: abort instead of writing a partial report if too many rows were malformed.
    if total_rows and (malformed_count / total_rows) > MAX_MALFORMED_RATIO:
        logger.critical(
            "%d/%d CDR rows (%.1f%%) were malformed -- exceeds the %.0f%% threshold. Aborting without writing a report.",
            malformed_count, total_rows, 100 * malformed_count / total_rows, 100 * MAX_MALFORMED_RATIO,
        )
        sys.exit(1)

    report = build_report(subscribers, cdrs, args.fraud_threshold_sec)
    write_report(report, args.output)
    logger.info("Report written to %s", args.output)

    print("\n=== Telecom CDR & Billing Insights -- Daily Summary ===")
    print(f"Subscribers processed    : {len(subscribers)}")
    print(f"CDRs processed           : {len(cdrs)} (skipped {malformed_count} malformed of {total_rows})")
    print(f"Unknown-subscriber CDRs  : {len(report['unknown_subscribers'])}")
    print(f"Fraud flags raised       : {len(report['fraud_flags'])}")
    print(f"Total revenue            : {report['total_revenue']}")


if __name__ == "__main__":
    main()
