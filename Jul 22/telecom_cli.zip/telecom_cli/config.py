"""
Central configuration for the Telecom CDR & Billing Insights CLI.

Per the project's coding standards, every constant used elsewhere in this package lives here --
no magic numbers scattered across modules.
"""

RATES = {
    "domestic": 1.5,
    "roaming": 8.0,
    "international": 12.0,
}

DEFAULT_FRAUD_THRESHOLD_SEC = 3600

# NFR2: abort instead of writing a partial report if more than this fraction of CDR rows in a
# batch are malformed.
MAX_MALFORMED_RATIO = 0.10
