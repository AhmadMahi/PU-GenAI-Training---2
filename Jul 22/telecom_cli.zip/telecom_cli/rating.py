"""
Rating engine for the Telecom CDR & Billing Insights CLI (FR4 / Milestone 2 Q2.1).

Milestone 1 (Q1.3) had this as an if/elif/else chain over the rate table; this is the Milestone 2
refactor to a dict lookup, which is what ships in the final solution.
"""

from config import RATES


def compute_cost(call_type: str, duration_sec: int) -> float:
    """Compute the billable cost of a single call.

    Args:
        call_type: one of "domestic", "roaming", "international". Anything else falls back to
            the domestic rate rather than raising -- rating should never be the reason a batch fails.
        duration_sec: call duration in seconds.
    Returns:
        Cost rounded to 2 decimal places.
    """
    rate = RATES.get(call_type, RATES["domestic"])
    minutes = duration_sec / 60
    return round(minutes * rate, 2)
