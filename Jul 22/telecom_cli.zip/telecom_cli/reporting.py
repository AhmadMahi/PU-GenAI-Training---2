"""
Report aggregation for the Telecom CDR & Billing Insights CLI (FR6/FR7/FR8 / Milestone 2 Q2.4).
"""


def build_report(subscribers: dict, cdrs: list, fraud_threshold_sec: int) -> dict:
    """Aggregate per-subscriber totals, unknown-subscriber anomalies, and fraud flags.

    Args:
        subscribers: dict of msisdn -> Subscriber, already loaded (calls list starts empty).
        cdrs: list of CDR instances, already rated.
        fraud_threshold_sec: threshold used by CDR.is_suspicious().
    Returns:
        A JSON-serializable report dict.
    """
    unknown_msisdns = set()  # Q2.4: msisdns present in the CDR batch but not in the subscriber list
    fraud_flags = []

    for cdr in cdrs:
        subscriber = subscribers.get(cdr.msisdn)
        if subscriber is None:
            unknown_msisdns.add(cdr.msisdn)
            continue

        subscriber.calls.append(cdr)
        if cdr.is_suspicious(fraud_threshold_sec):
            fraud_flags.append({
                "msisdn": cdr.msisdn,
                "call_type": cdr.call_type,
                "duration_sec": cdr.duration_sec,
                "cost": cdr.cost,
            })

    per_subscriber = {
        msisdn: {
            "plan_type": sub.plan_type,
            "call_count": len(sub.calls),
            "total_cost": sub.total_cost(),
        }
        for msisdn, sub in subscribers.items()
    }

    return {
        "per_subscriber": per_subscriber,
        "unknown_subscribers": sorted(unknown_msisdns),
        "fraud_flags": fraud_flags,
        "total_revenue": round(sum(s["total_cost"] for s in per_subscriber.values()), 2),
    }
