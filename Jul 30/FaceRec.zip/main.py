import os

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, File, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse

load_dotenv()

app = FastAPI(title="FaceCheck - Azure AI Face API Demo")

FACE_ENDPOINT = os.environ["AZURE_FACE_ENDPOINT"].rstrip("/")
FACE_KEY = os.environ["AZURE_FACE_KEY"]

DETECT_URL = f"{FACE_ENDPOINT}/face/v1.0/detect"


@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    with open("index.html", "r", encoding="utf-8") as f:
        return f.read()


@app.post("/detect-face")
async def detect_face(file: UploadFile = File(...)):
    """Send the uploaded image straight to Azure's Face API and return
    whatever face rectangles it finds."""
    image_bytes = await file.read()

    params = {
        # Kept deliberately minimal — no faceId, no attributes (age/gender/
        # emotion etc. are Limited Access features that need separate
        # Microsoft approval). Plain bounding-box detection works on any
        # standard Face resource, no extra approval needed.
        "returnFaceId": "false",
        "returnFaceLandmarks": "false",
        "detectionModel": "detection_03",
    }
    headers = {
        "Ocp-Apim-Subscription-Key": FACE_KEY,
        "Content-Type": "application/octet-stream",
    }

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            DETECT_URL, params=params, headers=headers, content=image_bytes
        )

    if response.status_code != 200:
        return JSONResponse(status_code=response.status_code, content={"error": response.text})

    faces = response.json()
    return {"count": len(faces), "faces": faces}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8004, reload=True)
